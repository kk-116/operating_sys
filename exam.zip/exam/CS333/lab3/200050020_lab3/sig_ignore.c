#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>


int main(){

    pid_t id = getpid();
    printf("Process Id is: %d\n" , id);
    signal(SIGINT, SIG_IGN);
    signal(SIGTERM, SIG_IGN);
    while (1){
        printf("Waiting...\n");
        sleep(3);
    }
    

}