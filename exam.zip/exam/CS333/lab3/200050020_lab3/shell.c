#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <stdbool.h>

#define MAX_INPUT_SIZE 1024
#define MAX_TOKEN_SIZE 64
#define MAX_NUM_TOKENS 64

// TODO: YOUR CODE HERE
// INITIALIZE DATA STRUCTURE TO STORE PIDS OF PROCESSES TO KILL LATER

pid_t ids[64];

/* Splits the string by space and returns the array of tokens
*
*/
char **tokenize(char *line) {

    // tokenizer variables
	char **tokens = (char **)malloc(MAX_NUM_TOKENS * sizeof(char *));
	char *token = (char *)malloc(MAX_TOKEN_SIZE * sizeof(char));
	int i, tokenIndex = 0, tokenNo = 0;

    // loop on length of line
	for(i=0; i < strlen(line); i++){

		char readChar = line[i];

        // tokenize on any kind of space
		if (readChar == ' ' || readChar == '\n' || readChar == '\t'){
			token[tokenIndex] = '\0';
			if (tokenIndex != 0) {
				tokens[tokenNo] = (char*)malloc(MAX_TOKEN_SIZE*sizeof(char));
				strcpy(tokens[tokenNo++], token);
				tokenIndex = 0; 
			}
		}
		else {
			token[tokenIndex++] = readChar;
		}
	}
	
	free(token);
	tokens[tokenNo] = NULL ;
	return tokens;
}

// TODO
// MAKE FUNCTIONS AS REQUIRED TO AVOID REPETITIVE WORK

int main(int argc, char* argv[]) {

	

	char  line[MAX_INPUT_SIZE];            
	char  **tokens;           

	// TODO: YOUR CODE HERE
	// INITIALIZE GLOBAL DATA STRUCTURE OF PIDS TO SOME DEFAULT VALUE  
	// INITIALIZE OTHER VARIABLES AS NEEDED

	char *cd = "cd";
	char *andand = "&&";
	char *andandand = "&&&";
	char *exit1 = "exit";

	while(1) {	

		/* BEGIN: TAKING INPUT */
		bzero(line, sizeof(line));
		printf("$ ");
		scanf("%[^\n]", line);
		getchar();
		/* END: TAKING INPUT */

		line[strlen(line)] = '\n'; //terminate with new line
		tokens = tokenize(line);

		int no_of_tokens = 0;
		
		

		bool triple = 0;
		for (int i = 0; i < MAX_NUM_TOKENS; i++){
			if(tokens[i] == NULL) break;
			if( strcmp(tokens[i] , andandand) == 0){
				triple = 1;
			}
			no_of_tokens++;
		}

		char **args = (char **)malloc(MAX_NUM_TOKENS * sizeof(char *));
		int index = 0;
		if( strcmp(tokens[0] , exit1)==0){
			
			exit(0);

		}
		else if(triple){

			for(int i=0; i<=no_of_tokens; i++){
				if(  i==no_of_tokens || ( strcmp(tokens[i] , andandand) == 0)){
					args[index] = NULL;
					if(strcmp( args[0] , cd) == 0){
						chdir(args[1]);
					}
					else{
						if(fork() == 0){
							execvp(args[0], args);
							exit(0);
						}
					}
					free(args);
					index = 0;
				}
				else{
					args[index] = tokens[i];
					index++;
				}
			}

			pid_t wpid;
    		int status = 0;
    		while ((wpid = wait(&status)) > 0);


		}
		else{
			for(int i=0; i<=no_of_tokens; i++){
				if(  i==no_of_tokens || ( strcmp(tokens[i] , andand) == 0)){
					args[index] = NULL;
					if(strcmp( args[0] , cd) == 0){
						chdir(args[1]);
					}
					else{
						pid_t cid = fork();
						if(cid == 0){
							execvp(args[0], args);
							exit(0);
						}
						else{
							wait(NULL);
						}
					}
					free(args);
					index = 0;
				}
				else{
					args[index] = tokens[i];
					index++;
				}
			}
		}
		
    
        // freeing the memory
		for(int i=0;tokens[i]!=NULL;i++){
			free(tokens[i]);
		}

		free(tokens);

	}

	
}


