#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>


int main(int argc, char* argv[]){

    pid_t id = atoi(argv[1]);
    
    if(kill( id, SIGINT) == 0){
        printf("SIGINT signal sent to PID: %d\n" , id);
    }
    //adding sleep(1) to see when will the program is killed
    sleep(1);
    if( kill( id, SIGTERM) == 0 ){
        printf("SIGTERM signal sent to PID: %d\n" , id);
    }
    sleep(1);
    if( kill( id, SIGKILL) == 0 ){
        printf("SIGKILL signal sent to PID: %d\n" , id);
    }
    sleep(1);


}