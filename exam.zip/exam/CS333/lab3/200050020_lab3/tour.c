#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include<string.h>

#define NUM_FRIEND 5

int friend_count = 0;

struct sigaction act1,act2;


void int_handler(int signum, siginfo_t *info, void *ptr){
    printf("\n\nYou have interrupted the tour\n");
    if (friend_count == 5){
        printf("All 5 friends have completed the tours.\n");
        printf("Thank you for visiting the Dinosaurs park\n");
        exit(0);
    }
    else{
        printf("Oh Sorry! Only %d out of the 5 friends have completedthe tour.\n", friend_count);
    }
}

void child_handler(int signum, siginfo_t *info, void *ptr){
    friend_count++;
}

int main(int argc, char *argv[]){

    printf("Welcome to the Dinosaurs Park.\n");



    memset(&act1, 0, sizeof(act1));
    act1.sa_sigaction = int_handler;
    act1.sa_flags = SA_RESTART;

    memset(&act2, 0, sizeof(act2));
    act2.sa_sigaction = child_handler;
    act2.sa_flags = SA_RESTART;


    sigaction(SIGINT, &act1, NULL);
    sigaction(SIGCHLD , &act2 , NULL);


    printf("The Process ID of Dinosaurs Park: %d \n", getpid());
    for (size_t friend = 1; friend <= NUM_FRIEND; friend ++){
        if (fork() == 0){
            setpgid(getpid(), 0);
            sleep(5 * friend); 
            printf("Friend #%zu with process ID - %d has completed the tour.\n", friend, getpid());
            exit(0);
        }
    }

    for (;;)
        pause(); 
    return 0;
}
