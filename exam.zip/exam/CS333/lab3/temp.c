#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>

int main(){
    while (1)
    {
        /* code */
        printf("%d\n" , getpid());
        sleep(60);
    }
    
}