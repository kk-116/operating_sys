#include <bits/stdc++.h>
using namespace std;

int main() {
    
	long long t; cin >> t;
	
	while(t--){
	    
	    long long  n, m;
	    string a;
	    cin >> n >> m >> a;
	    
	    vector<long long > dp((n*m) , 0);
	    for(long long  i=0; i<(n*m); i++){
	        long long  x = i%n;
	        if(i==0){
	            if(a[x] == '1'){
	                dp[i] = 1;
	            }
	        }
	        else{
	            if(a[x] == '1'){
	                dp[i] = 1 + dp[i-1];
	            }
	            else{
	                dp[i] = dp[i-1];
	            }
	        }
	    }
	    
	    long long  sum = dp[(n*m)-1];
	    long long  ans = 0;
	    for(long long  i=0; i<(n*m); i++){
	       // cout << dp[i] << " ";
	        if((2*dp[i]) == sum ){
	            ans ++;
	        }
	    }
	    
	   // cout << endl;
	    
	    cout << ans << endl;
	}
	return 0;
}
