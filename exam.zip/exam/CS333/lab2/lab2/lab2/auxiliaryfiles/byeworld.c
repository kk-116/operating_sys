#include<stdio.h>
int main(){
    printf("this is bye world program \n");
    return 0;
}