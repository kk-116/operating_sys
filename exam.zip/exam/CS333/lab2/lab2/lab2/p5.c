#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

int main(int argc, char *argv[]){
    int p1[2], p2[2];
    pipe(p1);
    pipe(p2);
    int x, y, z;

    pid_t pid = fork();
    if (pid != 0){

        close(p1[0]);
        close(p2[0]);
        scanf("%d", &x);
        scanf("%d", &y);
        write(p1[1], &x, sizeof(x));
        printf("Process A : Input value of x : %d\n", x);
        printf("Process B : Input value of y : %d\n", y);
        close(p1[1]);

        z = x + y;
        write(p2[1], &z, sizeof(z));
        close(p2[1]);
    }
    else{
        close(p1[1]);
        close(p2[1]);
        read(p1[0], &x, sizeof(x));
        read(p2[0], &z, sizeof(z));
        printf("Process C : Result after addition : %d\n", z);
        close(p1[0]);
        close(p2[0]);
    }
    return 0;
}