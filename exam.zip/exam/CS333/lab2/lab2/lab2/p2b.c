#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main(){

    int n;
    printf("Enter n value:");
    scanf("%d", &n);

    pid_t pid =  fork();

    if(pid < 0){
        printf("child process is not created\n");
    }
    else if(pid == 0){
        for (int i = 1; i <= n; i++){
            printf("C %d %d\n", getpid(), i);
        }
    }
    else{
        wait(NULL);
        for (int i = 1; i <= n; i++){
            printf("P %d %d\n", getpid(), n+i);
        }
        
    }
    return 0;
}