#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>
#include<stdbool.h>

int main(int argc, char *argv[]){

    int n = atoi(argv[1]);

    printf("Parent is : %d\n" , getpid());
    printf("Number of children: %d\n" , n);

    bool is_mainParent = true;
    bool is_last_child = false;

    for(int i=0; i<n; i++){
        pid_t pid =  fork();
        if(pid == 0){
            printf("Child %d is created\n", getpid());
            is_mainParent = 0;
            continue;
        }
        else{
            wait(NULL);
                printf("Child %d of parent %d exited\n" , pid , getpid());
            break;
        }
        
    }
    if(is_mainParent){
        printf("Parent exited\n");
    }
    return 0;
}