#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>
#include<stdbool.h>

int main(int argc, char *argv[]){

    int n = atoi(argv[1]);
    printf("Parent is : %d\n" , getpid());
    printf("Number of children: %d\n" , n);

    for(int i=0; i<n; i++){
        pid_t pid =  fork();
        if(pid == 0){
            printf("Child %d is created\n", getpid());
            sleep(1);
            printf("Child %d of parent %d exited\n", getpid() , getppid());
            exit(0);
        }
    }

    pid_t wpid;
    int status = 0;
    while ((wpid = wait(&status)) > 0);
    printf("Parent exited\n");
    return 0;
}
